package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleAppTest {

  @Test
  fun testAppNameConstant() {
    val expectedName = "ViralShorts AI"
    assertEquals("ViralShorts AI", expectedName)
  }
}
