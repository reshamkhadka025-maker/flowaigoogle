package com.example

import com.example.data.VideoRepository
import com.example.model.CaptionStylePreset
import com.example.model.Language
import com.example.model.VoiceCloneProfile
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testInitialProjectsAndClips() {
        val repo = VideoRepository()
        val projects = repo.projects.value

        assertTrue("Should have initial demo projects", projects.isNotEmpty())
        val firstProject = projects.first()
        assertTrue("Project should have clips", firstProject.clips.isNotEmpty())

        val firstClip = firstProject.clips.first()
        assertTrue("Virality score should be between 0 and 100", firstClip.viralityScore in 0..100)
        assertTrue("Duration should be greater than 0", firstClip.durationSec > 0)
        assertTrue("Transcript should not be empty", firstClip.transcript.isNotEmpty())
    }

    @Test
    fun testClipUpdate() {
        val repo = VideoRepository()
        val originalClip = repo.projects.value.first().clips.first()
        val updatedHeadline = "NEW VIRAL TEST HOOK 🔥"
        val updatedClip = originalClip.copy(hookHeadline = updatedHeadline)

        repo.updateClip(updatedClip)

        val retrievedClip = repo.getClip(originalClip.id)
        assertNotNull(retrievedClip)
        assertEquals(updatedHeadline, retrievedClip?.hookHeadline)
    }

    @Test
    fun testVoiceProfiles() {
        val repo = VideoRepository()
        val initialCount = repo.voiceProfiles.value.size

        val newProfile = VoiceCloneProfile(
            id = "test_profile_1",
            speakerName = "Test Creator",
            consentStatement = "Authorized by creator",
            consentTimestamp = System.currentTimeMillis(),
            sampleDurationSec = 30
        )
        repo.addVoiceProfile(newProfile)

        assertEquals(initialCount + 1, repo.voiceProfiles.value.size)
        assertEquals("Test Creator", repo.voiceProfiles.value.first().speakerName)
    }

    @Test
    fun testCaptionPresetsAndLanguages() {
        assertEquals(4, CaptionStylePreset.ALL_PRESETS.size)
        assertTrue("Should support Spanish", Language.SUPPORTED_LANGUAGES.any { it.code == "es" })
        assertTrue("Should support Japanese", Language.SUPPORTED_LANGUAGES.any { it.code == "ja" })
        assertTrue("Should support Hindi", Language.SUPPORTED_LANGUAGES.any { it.code == "hi" })
    }
}
