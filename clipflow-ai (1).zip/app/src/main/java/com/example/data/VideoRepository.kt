package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.model.AspectCropMode
import com.example.model.CaptionStylePreset
import com.example.model.CaptionWord
import com.example.model.CopyrightAudit
import com.example.model.Language
import com.example.model.LongVideoProject
import com.example.model.MusicTrack
import com.example.model.PlatformOverlay
import com.example.model.SafetyLevel
import com.example.model.ViralClip
import com.example.model.VoiceCloneProfile
import com.example.model.VoicePersona
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import java.util.UUID

class VideoRepository {

    private val _projects = MutableStateFlow<List<LongVideoProject>>(createInitialProjects())
    val projects = _projects.asStateFlow()

    private val _voiceProfiles = MutableStateFlow<List<VoiceCloneProfile>>(createInitialVoiceProfiles())
    val voiceProfiles = _voiceProfiles.asStateFlow()

    fun getProject(id: String): LongVideoProject? {
        return _projects.value.find { it.id == id }
    }

    fun getClip(clipId: String): ViralClip? {
        for (project in _projects.value) {
            val found = project.clips.find { it.id == clipId }
            if (found != null) return found
        }
        return null
    }

    fun updateClip(updatedClip: ViralClip) {
        val currentList = _projects.value.toMutableList()
        val projectIndex = currentList.indexOfFirst { it.id == updatedClip.projectId }
        if (projectIndex != -1) {
            val project = currentList[projectIndex]
            val clipIndex = project.clips.indexOfFirst { it.id == updatedClip.id }
            if (clipIndex != -1) {
                val updatedClips = project.clips.toMutableList()
                updatedClips[clipIndex] = updatedClip
                currentList[projectIndex] = project.copy(clips = updatedClips)
                _projects.value = currentList
            }
        }
    }

    fun addVoiceProfile(profile: VoiceCloneProfile) {
        _voiceProfiles.value = listOf(profile) + _voiceProfiles.value
    }

    /**
     * Simulates the complete AI pipeline from a URL or uploaded local video
     */
    fun processVideo(
        title: String,
        sourceUrl: String?,
        fileName: String?,
        targetLanguage: Language = Language.ORIGINAL
    ): Flow<Pair<Int, String>> = flow {
        emit(10 to "Connecting to media stream & extracting high-res frames...")
        delay(700)
        emit(25 to "Transcribing audio & detecting punchlines with Whisper AI...")
        delay(800)
        emit(45 to "Analyzing viral retention markers & emotional resonance peaks...")
        delay(900)
        emit(65 to "Generating 9:16 vertical crop with active speaker face-tracking...")
        delay(800)
        emit(82 to "Synthesizing Hormozi-style kinetic captions & emoji highlights...")
        delay(800)
        emit(94 to "Executing copyright & Content ID monetization safety audit...")
        delay(600)
        emit(100 to "Generated viral clips successfully!")

        val newProject = generateGeneratedProject(title, sourceUrl, fileName, targetLanguage)
        _projects.value = listOf(newProject) + _projects.value
    }

    private fun generateGeneratedProject(
        title: String,
        sourceUrl: String?,
        fileName: String?,
        targetLanguage: Language
    ): LongVideoProject {
        val projectId = UUID.randomUUID().toString()
        val sanitizedTitle = if (title.isNotBlank()) title else "Viral Video Masterclass"

        val clip1 = ViralClip(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            title = "The $10M Framework Nobody Talks About",
            hookHeadline = "STOP DOING THIS IN 2025! 🛑",
            startSec = 12,
            endSec = 48,
            viralityScore = 98,
            hookStrengthScore = 96,
            emotionalSpikeType = "Shocking Revelation",
            viralReason = "Strong opening contradiction causes 87% scroll-stop rate. High retention anticipated in first 3 seconds.",
            transcript = listOf(
                CaptionWord("If", 0, 200),
                CaptionWord("you", 200, 400),
                CaptionWord("are", 400, 600),
                CaptionWord("still", 600, 900),
                CaptionWord("posting", 900, 1300, isEmphasized = true),
                CaptionWord("without", 1300, 1600),
                CaptionWord("captions,", 1600, 2100, isEmphasized = true, emoji = "📝"),
                CaptionWord("you", 2100, 2300),
                CaptionWord("are", 2300, 2500),
                CaptionWord("losing", 2500, 2900, isEmphasized = true),
                CaptionWord("eighty", 2900, 3300),
                CaptionWord("percent", 3300, 3700, isEmphasized = true, emoji = "📉"),
                CaptionWord("of", 3700, 3900),
                CaptionWord("your", 3900, 4100),
                CaptionWord("audience", 4100, 4600),
                CaptionWord("instantly.", 4600, 5200, emoji = "⚡")
            ),
            captionStyle = CaptionStylePreset.HORMOZI,
            cropMode = AspectCropMode.AUTO_SPEAKER_TRACK,
            platformOverlay = PlatformOverlay.TIKTOK,
            dubbingLanguage = targetLanguage,
            hashtags = listOf("#growthmindset", "#viralvideo", "#shorts", "#creatorsecrets", "#hustle"),
            seoDescription = "The exact secret high-ticket creators use to dominate short-form video in 2025. Save this for later! 💡"
        )

        val clip2 = ViralClip(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            title = "The 3-Second Psychological Hook",
            hookHeadline = "WAIT TILL THE END 😱",
            startSec = 75,
            endSec = 124,
            viralityScore = 94,
            hookStrengthScore = 92,
            emotionalSpikeType = "High Tension Cliffhanger",
            viralReason = "Fast-paced storytelling keeps completion rate above 92%. Perfect for YouTube Shorts algorithmic push.",
            transcript = listOf(
                CaptionWord("The", 0, 200),
                CaptionWord("first", 200, 500),
                CaptionWord("three", 500, 800, isEmphasized = true),
                CaptionWord("seconds", 800, 1200, isEmphasized = true, emoji = "⏱️"),
                CaptionWord("determine", 1200, 1700),
                CaptionWord("if", 1700, 1900),
                CaptionWord("your", 1900, 2100),
                CaptionWord("video", 2100, 2400),
                CaptionWord("explodes", 2400, 3000, isEmphasized = true, emoji = "💥"),
                CaptionWord("or", 3000, 3200),
                CaptionWord("dies", 3200, 3600),
                CaptionWord("in", 3600, 3800),
                CaptionWord("the", 3800, 4000),
                CaptionWord("algorithm.", 4000, 4700, emoji = "📉")
            ),
            captionStyle = CaptionStylePreset.MR_BEAST,
            cropMode = AspectCropMode.AUTO_SPEAKER_TRACK,
            platformOverlay = PlatformOverlay.REELS,
            dubbingLanguage = targetLanguage,
            hashtags = listOf("#tiktokviral", "#contentcreator", "#youtubeshorts", "#growthhacks"),
            seoDescription = "Master the 3-second hook rule and watch your short form analytics skyrocket!"
        )

        val clip3 = ViralClip(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            title = "Why 99% Of People Fail At This",
            hookHeadline = "BRUTAL TRUTH ALERT 🚨",
            startSec = 145,
            endSec = 192,
            viralityScore = 91,
            hookStrengthScore = 89,
            emotionalSpikeType = "Controversial Take",
            viralReason = "Strong conversational debate starter driving massive comments and shares in TikTok For You feed.",
            transcript = listOf(
                CaptionWord("Most", 0, 300),
                CaptionWord("people", 300, 600),
                CaptionWord("quit", 600, 1000, isEmphasized = true),
                CaptionWord("right", 1000, 1300),
                CaptionWord("before", 1300, 1700),
                CaptionWord("the", 1700, 1900),
                CaptionWord("compound", 1900, 2400, isEmphasized = true),
                CaptionWord("effect", 2400, 2800),
                CaptionWord("actually", 2800, 3200),
                CaptionWord("kicks", 3200, 3500),
                CaptionWord("in.", 3500, 4000, emoji = "🚀")
            ),
            captionStyle = CaptionStylePreset.CYBER_NEON,
            cropMode = AspectCropMode.DUAL_SPLIT,
            platformOverlay = PlatformOverlay.YOUTUBE_SHORTS,
            dubbingLanguage = targetLanguage,
            hashtags = listOf("#mindset", "#discipline", "#successquotes", "#reelsinstagram"),
            seoDescription = "Don't quit on day 30 when the breakthrough happens on day 31. Drop a 💯 if you agree!"
        )

        return LongVideoProject(
            id = projectId,
            title = sanitizedTitle,
            sourceUrl = sourceUrl,
            sourceFileName = fileName,
            originalDurationSec = 940,
            thumbnailGradient = listOf(Color(0xFF8B5CF6), Color(0xFF06B6D4)),
            clips = listOf(clip1, clip2, clip3)
        )
    }

    private fun createInitialProjects(): List<LongVideoProject> {
        val proj1Id = "proj_lex_ai"
        val proj1 = LongVideoProject(
            id = proj1Id,
            title = "The Future of AGI & Synthetic Voices",
            sourceUrl = "https://youtube.com/watch?v=lex_agi_deep_dive",
            sourceFileName = null,
            originalDurationSec = 3600,
            thumbnailGradient = listOf(Color(0xFF6366F1), Color(0xFFEC4899)),
            clips = listOf(
                ViralClip(
                    id = "clip_agi_1",
                    projectId = proj1Id,
                    title = "Will AI Voice Replace Real Singers?",
                    hookHeadline = "HEAR THIS REALISTIC VOICE 🤖",
                    startSec = 340,
                    endSec = 385,
                    viralityScore = 97,
                    hookStrengthScore = 95,
                    emotionalSpikeType = "Shocking Tech Demo",
                    viralReason = "Auditory surprise factor creates immediate 94% retention with massive comment debates.",
                    transcript = listOf(
                        CaptionWord("When", 0, 200),
                        CaptionWord("you", 200, 400),
                        CaptionWord("hear", 400, 700),
                        CaptionWord("a", 700, 850),
                        CaptionWord("voice", 850, 1200, isEmphasized = true),
                        CaptionWord("cloned", 1200, 1600, isEmphasized = true, emoji = "🎙️"),
                        CaptionWord("with", 1600, 1800),
                        CaptionWord("perfect", 1800, 2200),
                        CaptionWord("pitch", 2200, 2600),
                        CaptionWord("and", 2600, 2800),
                        CaptionWord("timbre,", 2800, 3300),
                        CaptionWord("the", 3300, 3500),
                        CaptionWord("brain", 3500, 3900, isEmphasized = true, emoji = "🧠"),
                        CaptionWord("cannot", 3900, 4300),
                        CaptionWord("tell", 4300, 4600),
                        CaptionWord("the", 4600, 4800),
                        CaptionWord("difference.", 4800, 5400, emoji = "✨")
                    ),
                    captionStyle = CaptionStylePreset.HORMOZI,
                    cropMode = AspectCropMode.AUTO_SPEAKER_TRACK,
                    platformOverlay = PlatformOverlay.TIKTOK,
                    hashtags = listOf("#ai", "#techtrends", "#voiceclone", "#artificialintelligence", "#futuretech"),
                    seoDescription = "Is synthetic voice indistinguishable from reality now? Mind officially blown. 🤯"
                ),
                ViralClip(
                    id = "clip_agi_2",
                    projectId = proj1Id,
                    title = "The Secret Reason People Scroll Past",
                    hookHeadline = "DON'T MAKE THIS MISTAKE ⚠️",
                    startSec = 820,
                    endSec = 862,
                    viralityScore = 92,
                    hookStrengthScore = 90,
                    emotionalSpikeType = "Actionable Advice",
                    viralReason = "Direct question hook in opening millisecond stops viewers in their tracks.",
                    transcript = listOf(
                        CaptionWord("Notice", 0, 300),
                        CaptionWord("how", 300, 500),
                        CaptionWord("every", 500, 800),
                        CaptionWord("viral", 800, 1200, isEmphasized = true, emoji = "🔥"),
                        CaptionWord("reel", 1200, 1500),
                        CaptionWord("changes", 1500, 1900),
                        CaptionWord("camera", 1900, 2300),
                        CaptionWord("angle", 2300, 2700),
                        CaptionWord("every", 2700, 3000),
                        CaptionWord("two", 3000, 3300, isEmphasized = true),
                        CaptionWord("seconds.", 3300, 3800, emoji = "👁️")
                    ),
                    captionStyle = CaptionStylePreset.MR_BEAST,
                    cropMode = AspectCropMode.CENTER_9_16,
                    platformOverlay = PlatformOverlay.REELS,
                    hashtags = listOf("#editingtips", "#shortscreator", "#videomarketing", "#reelsviral"),
                    seoDescription = "The micro-pacing secret top video editors don't want you to know!"
                )
            )
        )

        val proj2Id = "proj_creators"
        val proj2 = LongVideoProject(
            id = proj2Id,
            title = "Zero to 1 Million Subscribers Blueprint",
            sourceUrl = "https://youtube.com/watch?v=growth_mastery_podcast",
            sourceFileName = null,
            originalDurationSec = 2400,
            thumbnailGradient = listOf(Color(0xFF06B6D4), Color(0xFF10B981)),
            clips = listOf(
                ViralClip(
                    id = "clip_sub_1",
                    projectId = proj2Id,
                    title = "How 1 Short Generated 10,000 Subs",
                    hookHeadline = "10K SUBS IN 24 HOURS! 📈",
                    startSec = 150,
                    endSec = 195,
                    viralityScore = 96,
                    hookStrengthScore = 94,
                    emotionalSpikeType = "Proof of Results",
                    viralReason = "Insane case study proof draws heavy bookmarking and algorithm velocity.",
                    transcript = listOf(
                        CaptionWord("We", 0, 200),
                        CaptionWord("took", 200, 450),
                        CaptionWord("one", 450, 700),
                        CaptionWord("sixty-second", 700, 1200, isEmphasized = true),
                        CaptionWord("clip,", 1200, 1600, emoji = "🎬"),
                        CaptionWord("dubbed", 1600, 2000),
                        CaptionWord("it", 2000, 2200),
                        CaptionWord("in", 2200, 2400),
                        CaptionWord("Spanish,", 2400, 2900, isEmphasized = true, emoji = "🇪🇸"),
                        CaptionWord("and", 2900, 3100),
                        CaptionWord("it", 3100, 3300),
                        CaptionWord("hit", 3300, 3600),
                        CaptionWord("five", 3600, 3900),
                        CaptionWord("million", 3900, 4400, isEmphasized = true, emoji = "🚀"),
                        CaptionWord("views.", 4400, 5000)
                    ),
                    captionStyle = CaptionStylePreset.CYBER_NEON,
                    cropMode = AspectCropMode.AUTO_SPEAKER_TRACK,
                    platformOverlay = PlatformOverlay.YOUTUBE_SHORTS,
                    dubbingLanguage = Language.SPANISH,
                    hashtags = listOf("#multilingual", "#dubbing", "#youtubegrowth", "#viralhack"),
                    seoDescription = "Globalize your content with multilingual AI dubbing and 10x your reach."
                )
            )
        )

        return listOf(proj1, proj2)
    }

    private fun createInitialVoiceProfiles(): List<VoiceCloneProfile> {
        return listOf(
            VoiceCloneProfile(
                id = "vp_alex",
                speakerName = "My Verified Voice (Primary)",
                consentStatement = "I authorize ViralShorts AI to generate synthetic speech in my verified vocal likeness for my personal content creation.",
                consentTimestamp = System.currentTimeMillis() - 86400000L * 3,
                sampleDurationSec = 32,
                similarityConfidence = 99,
                status = "Active & Ready"
            ),
            VoiceCloneProfile(
                id = "vp_studio",
                speakerName = "Host Secondary Mic",
                consentStatement = "Authorized for studio interview repurposing.",
                consentTimestamp = System.currentTimeMillis() - 86400000L * 7,
                sampleDurationSec = 45,
                similarityConfidence = 96,
                status = "Active & Ready"
            )
        )
    }
}
