package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Studio Palette for ViralShorts AI
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceCard = Color(0xFF161F30)

// Vibrant Cyber & Viral Accents
val NeonViolet = Color(0xFF8B5CF6)
val NeonIndigo = Color(0xFF6366F1)
val NeonCyan = Color(0xFF06B6D4)
val NeonPink = Color(0xFFEC4899)
val SunsetOrange = Color(0xFFF97316)
val ViralFlame = Color(0xFFFF4D4D)
val ViralGold = Color(0xFFFBBF24)
val EmeraldGreen = Color(0xFF10B981)

// Typography & Neutrals
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val BorderSubtle = Color(0xFF2E3B52)
val BorderGlow = Color(0xFF384B6E)

// Caption highlight colors
val CaptionHormoziYellow = Color(0xFFFFDE03)
val CaptionHormoziGreen = Color(0xFF00FF66)
val CaptionHormoziRed = Color(0xFFFF2A2A)
val CaptionCyanGlow = Color(0xFF00E5FF)
val CaptionNeonPink = Color(0xFFFF1493)
