package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AspectCropMode
import com.example.model.CaptionAnimationStyle
import com.example.model.CaptionStylePreset
import com.example.model.CaptionWord
import com.example.model.Language
import com.example.model.PlatformOverlay
import com.example.model.ViralClip
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.ViralFlame
import com.example.ui.theme.ViralGold
import kotlinx.coroutines.delay
import kotlin.math.sin

@Composable
fun VerticalVideoPlayer(
    clip: ViralClip,
    modifier: Modifier = Modifier,
    isPlayingDefault: Boolean = true,
    showControls: Boolean = true,
    onClipChange: ((ViralClip) -> Unit)? = null
) {
    var isPlaying by remember { mutableStateOf(isPlayingDefault) }
    var currentPlaybackMs by remember { mutableLongStateOf(0L) }
    val totalDurationMs = remember(clip.durationSec) { (clip.durationSec * 1000L).coerceAtLeast(1000L) }

    // Playback loop
    LaunchedEffect(isPlaying, clip.id) {
        while (isPlaying) {
            delay(50)
            currentPlaybackMs += 50
            if (currentPlaybackMs >= totalDurationMs) {
                currentPlaybackMs = 0L // Loop automatically like Reels/TikTok
            }
        }
    }

    // Infinite animation transition for lip sync and wave motion
    val infiniteTransition = rememberInfiniteTransition(label = "player_motion")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val speakerMouthOpening by infiniteTransition.animateFloat(
        initialValue = 2f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(
            animation = tween(180, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mouth"
    )

    val discRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "disc"
    )

    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.Black)
            .border(1.dp, Color(0xFF2E3B52), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) {
        // 9:16 Aspect ratio container
        Box(
            modifier = Modifier
                .fillMaxSize()
                .aspectRatio(9f / 16f)
                .clickable { isPlaying = !isPlaying }
        ) {
            // Simulated Video Visual Rendering Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("video_canvas")
            ) {
                drawSimulatedVideoScene(
                    clip = clip,
                    playbackMs = currentPlaybackMs,
                    totalMs = totalDurationMs,
                    mouthOpen = if (isPlaying) speakerMouthOpening else 2f,
                    pulse = if (isPlaying) pulseScale else 1f
                )
            }

            // Top Floating Hook Overlay (Viral Badge)
            if (clip.hookHeadline.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 18.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xE6FF1E56))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = clip.hookHeadline,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Center / Synchronized Kinetic Captions
            val currentWordIndex = remember(currentPlaybackMs, clip.transcript) {
                val cycleTime = (currentPlaybackMs % 5000L)
                val words = clip.transcript
                if (words.isEmpty()) -1
                else {
                    val idx = ((cycleTime.toFloat() / 5000f) * words.size).toInt()
                    idx.coerceIn(0, words.size - 1)
                }
            }

            KineticCaptionsOverlay(
                transcript = clip.transcript,
                currentIndex = currentWordIndex,
                style = clip.captionStyle,
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            )

            // Lip-Sync & Dubbing active pill indicator
            if (clip.dubbingLanguage != Language.ORIGINAL) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(top = 18.dp, start = 14.dp),
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xCC06B6D4)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "Lip-sync synced",
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${clip.dubbingLanguage.flagEmoji} ${clip.dubbingLanguage.name} • Lip-Sync",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Platform Safe-Zone Overlay (TikTok, Reels, Shorts UI mask)
            PlatformSafeZoneMask(
                platform = clip.platformOverlay,
                clip = clip,
                discRotation = discRotation,
                modifier = Modifier.fillMaxSize()
            )

            // Play / Pause central indicator (shows briefly or when paused)
            if (!isPlaying) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000))
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            // Bottom Scrubbing & Playback Controls Bar
            if (showControls) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xDD000000))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("player_play_pause_btn")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        val currentSeconds = (currentPlaybackMs / 1000).toInt()
                        Text(
                            text = String.format("%02d:%02d / %02d:%02d",
                                currentSeconds / 60, currentSeconds % 60,
                                clip.durationSec / 60, clip.durationSec % 60
                            ),
                            fontSize = 11.sp,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )

                        // Reframe indicator button
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0x44FFFFFF),
                            modifier = Modifier.clickable {
                                // Cycle crop modes on click
                                val nextMode = when (clip.cropMode) {
                                    AspectCropMode.AUTO_SPEAKER_TRACK -> AspectCropMode.DUAL_SPLIT
                                    AspectCropMode.DUAL_SPLIT -> AspectCropMode.CENTER_9_16
                                    AspectCropMode.CENTER_9_16 -> AspectCropMode.BLURRED_CANVAS
                                    AspectCropMode.BLURRED_CANVAS -> AspectCropMode.AUTO_SPEAKER_TRACK
                                }
                                onClipChange?.invoke(clip.copy(cropMode = nextMode))
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = clip.cropMode.label.take(12),
                                    fontSize = 10.sp,
                                    color = NeonCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Progress Slider
                    Slider(
                        value = currentPlaybackMs.toFloat(),
                        onValueChange = {
                            currentPlaybackMs = it.toLong()
                        },
                        valueRange = 0f..totalDurationMs.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = NeonPink,
                            activeTrackColor = NeonPink,
                            inactiveTrackColor = Color(0x55FFFFFF)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .testTag("player_timeline_slider")
                    )
                }
            }
        }
    }
}

/**
 * Draws realistic simulated studio scenes, podcasts, speaker face tracking and audio waveforms
 */
private fun DrawScope.drawSimulatedVideoScene(
    clip: ViralClip,
    playbackMs: Long,
    totalMs: Long,
    mouthOpen: Float,
    pulse: Float
) {
    val width = size.width
    val height = size.height

    // Background Studio Lighting Gradient
    val bgBrush = Brush.radialGradient(
        colors = listOf(
            Color(0xFF26194A),
            Color(0xFF130D29),
            Color(0xFF090616)
        ),
        center = Offset(width * 0.5f, height * 0.35f),
        radius = width * 0.9f
    )
    drawRect(brush = bgBrush)

    when (clip.cropMode) {
        AspectCropMode.AUTO_SPEAKER_TRACK -> {
            // Dynamic speaker tracking camera pan effect
            val panOffset = (sin(playbackMs / 900.0) * (width * 0.04f)).toFloat()
            drawSpeakerAvatar(
                centerOffset = Offset(width * 0.5f + panOffset, height * 0.42f),
                scale = 1.0f * pulse,
                mouthOpen = mouthOpen,
                speakerColor = Color(0xFF9333EA)
            )

            // Studio microphone
            drawStudioMic(Offset(width * 0.5f + panOffset, height * 0.52f))
        }

        AspectCropMode.DUAL_SPLIT -> {
            // Top pane: Speaker 1
            drawRoundRect(
                color = Color(0x33FFFFFF),
                topLeft = Offset(width * 0.05f, height * 0.10f),
                size = Size(width * 0.9f, height * 0.36f),
                cornerRadius = CornerRadius(16f, 16f)
            )
            drawSpeakerAvatar(
                centerOffset = Offset(width * 0.5f, height * 0.25f),
                scale = 0.75f * pulse,
                mouthOpen = mouthOpen,
                speakerColor = Color(0xFF6366F1)
            )

            // Divider bar
            drawLine(
                color = NeonCyan,
                start = Offset(width * 0.1f, height * 0.48f),
                end = Offset(width * 0.9f, height * 0.48f),
                strokeWidth = 3f
            )

            // Bottom pane: Reaction / Co-host
            drawRoundRect(
                color = Color(0x33FFFFFF),
                topLeft = Offset(width * 0.05f, height * 0.50f),
                size = Size(width * 0.9f, height * 0.36f),
                cornerRadius = CornerRadius(16f, 16f)
            )
            drawSpeakerAvatar(
                centerOffset = Offset(width * 0.5f, height * 0.65f),
                scale = 0.75f,
                mouthOpen = 3f,
                speakerColor = Color(0xFFEC4899)
            )
        }

        AspectCropMode.CENTER_9_16 -> {
            drawSpeakerAvatar(
                centerOffset = Offset(width * 0.5f, height * 0.45f),
                scale = 1.15f * pulse,
                mouthOpen = mouthOpen,
                speakerColor = Color(0xFF06B6D4)
            )
            drawStudioMic(Offset(width * 0.5f, height * 0.55f))
        }

        AspectCropMode.BLURRED_CANVAS -> {
            // Blurred canvas outer lines
            for (i in 0..10) {
                drawCircle(
                    color = Color(0x15FFFFFF),
                    radius = width * (0.3f + i * 0.06f),
                    center = Offset(width * 0.5f, height * 0.45f)
                )
            }
            // Centered 16:9 inner frame
            drawRoundRect(
                color = Color(0xFF1E293B),
                topLeft = Offset(width * 0.08f, height * 0.32f),
                size = Size(width * 0.84f, height * 0.26f),
                cornerRadius = CornerRadius(12f, 12f)
            )
            drawSpeakerAvatar(
                centerOffset = Offset(width * 0.5f, height * 0.45f),
                scale = 0.6f * pulse,
                mouthOpen = mouthOpen,
                speakerColor = Color(0xFF10B981)
            )
        }
    }

    // Audio reactive wave at bottom of visualizer
    val barCount = 20
    val barWidth = width * 0.025f
    val startX = width * 0.15f
    for (i in 0 until barCount) {
        val waveVal = (sin((playbackMs / 180.0) + i * 0.5) + 1.0) * 0.5
        val barHeight = (height * 0.04f * waveVal.toFloat() * pulse).coerceAtLeast(4f)
        drawRoundRect(
            color = if (i % 2 == 0) NeonCyan.copy(alpha = 0.6f) else NeonPink.copy(alpha = 0.6f),
            topLeft = Offset(startX + i * (barWidth + 4f), height * 0.74f - barHeight),
            size = Size(barWidth, barHeight),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }
}

private fun DrawScope.drawSpeakerAvatar(
    centerOffset: Offset,
    scale: Float,
    mouthOpen: Float,
    speakerColor: Color
) {
    val headRadius = 45f * scale

    // Head / Face
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFFDBAC), Color(0xFFE0AC69)),
            center = centerOffset,
            radius = headRadius
        ),
        radius = headRadius,
        center = centerOffset
    )

    // Hair / Studio Cap
    val hairPath = Path().apply {
        moveTo(centerOffset.x - headRadius * 1.05f, centerOffset.y)
        cubicTo(
            centerOffset.x - headRadius, centerOffset.y - headRadius * 1.3f,
            centerOffset.x + headRadius, centerOffset.y - headRadius * 1.3f,
            centerOffset.x + headRadius * 1.05f, centerOffset.y
        )
        close()
    }
    drawPath(hairPath, color = Color(0xFF231F20))

    // Eyes
    drawCircle(
        color = Color(0xFF1F2937),
        radius = 4f * scale,
        center = Offset(centerOffset.x - 14f * scale, centerOffset.y - 4f * scale)
    )
    drawCircle(
        color = Color(0xFF1F2937),
        radius = 4f * scale,
        center = Offset(centerOffset.x + 14f * scale, centerOffset.y - 4f * scale)
    )

    // Mouth with Lip-Sync animation
    drawRoundRect(
        color = Color(0xFF991B1B),
        topLeft = Offset(centerOffset.x - 10f * scale, centerOffset.y + 16f * scale),
        size = Size(20f * scale, mouthOpen * scale),
        cornerRadius = CornerRadius(6f, 6f)
    )

    // Torso / Studio Hoodie
    val bodyPath = Path().apply {
        moveTo(centerOffset.x - 55f * scale, centerOffset.y + headRadius + 50f * scale)
        lineTo(centerOffset.x - 30f * scale, centerOffset.y + headRadius - 5f * scale)
        lineTo(centerOffset.x + 30f * scale, centerOffset.y + headRadius - 5f * scale)
        lineTo(centerOffset.x + 55f * scale, centerOffset.y + headRadius + 50f * scale)
        close()
    }
    drawPath(bodyPath, color = speakerColor)
}

private fun DrawScope.drawStudioMic(offset: Offset) {
    drawRoundRect(
        color = Color(0xFF334155),
        topLeft = Offset(offset.x - 8f, offset.y - 18f),
        size = Size(16f, 32f),
        cornerRadius = CornerRadius(8f, 8f)
    )
    drawLine(
        color = Color(0xFF64748B),
        start = Offset(offset.x, offset.y + 14f),
        end = Offset(offset.x, offset.y + 40f),
        strokeWidth = 4f
    )
}

/**
 * High-impact kinetic captions overlay (Hormozi / MrBeast style)
 */
@Composable
fun KineticCaptionsOverlay(
    transcript: List<CaptionWord>,
    currentIndex: Int,
    style: CaptionStylePreset,
    modifier: Modifier = Modifier
) {
    if (transcript.isEmpty()) return

    // Show a window of 3-4 words centered on current word
    val windowSize = 4
    val startIndex = (currentIndex - 1).coerceAtLeast(0)
    val endIndex = (startIndex + windowSize).coerceAtMost(transcript.size)
    val displayWords = transcript.subList(startIndex, endIndex)

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .then(
                if (style.hasBackgroundBox) Modifier.background(style.boxColor).padding(horizontal = 10.dp, vertical = 6.dp)
                else Modifier
            ),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        displayWords.forEachIndexed { idx, item ->
            val globalIndex = startIndex + idx
            val isCurrent = globalIndex == currentIndex

            val wordText = if (style.isAllCaps) item.word.uppercase() else item.word
            val fullText = if (item.emoji != null && isCurrent) "$wordText ${item.emoji}" else wordText

            val color = if (isCurrent) style.highlightColor else style.textColor
            val scale = if (isCurrent && style.animation == CaptionAnimationStyle.BOUNCE_ZOOM) 1.25f else 1.0f

            Text(
                text = "$fullText ",
                color = color,
                fontSize = if (isCurrent) 22.sp else 18.sp,
                fontWeight = if (isCurrent || item.isEmphasized) FontWeight.Black else FontWeight.Bold,
                fontFamily = FontFamily.SansSerif,
                modifier = Modifier
                    .scale(scale)
                    .padding(horizontal = 2.dp)
            )
        }
    }
}

/**
 * Platform UI Safe-Zone Masks so creators know their text won't be blocked by TikTok/Reels UI
 */
@Composable
fun PlatformSafeZoneMask(
    platform: PlatformOverlay,
    clip: ViralClip,
    discRotation: Float,
    modifier: Modifier = Modifier
) {
    when (platform) {
        PlatformOverlay.NONE -> {
            // Clean view
        }

        PlatformOverlay.TIKTOK -> {
            Box(modifier = modifier) {
                // Right engagement stack
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 10.dp, bottom = 85.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Profile avatar
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF8B5CF6))
                            .border(1.5.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Like
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Favorite, contentDescription = "Like", tint = Color.White, modifier = Modifier.size(28.dp))
                        Text("124K", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Comment
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ChatBubble, contentDescription = "Comment", tint = Color.White, modifier = Modifier.size(26.dp))
                        Text("1.8K", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Bookmark
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Bookmark, contentDescription = "Save", tint = Color.White, modifier = Modifier.size(26.dp))
                        Text("45K", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Share
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(26.dp))
                        Text("12K", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Spinning Vinyl
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(2.dp, Color(0xFF64748B), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = "Sound", tint = NeonPink, modifier = Modifier.size(16.dp))
                    }
                }

                // Bottom Metadata & Safe Area Guide
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 28.dp, end = 70.dp)
                ) {
                    Text(
                        text = "@viralshorts.ai",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${clip.title} #viral #shorts #fyp",
                        color = Color(0xEEFFFFFF),
                        fontSize = 11.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        PlatformOverlay.REELS -> {
            Box(modifier = modifier) {
                // Right engagement buttons
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 12.dp, bottom = 70.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(Icons.Default.Favorite, contentDescription = "Like", tint = Color.White, modifier = Modifier.size(26.dp))
                    Text("89K", color = Color.White, fontSize = 10.sp)
                    Icon(Icons.Default.ChatBubble, contentDescription = "Comment", tint = Color.White, modifier = Modifier.size(24.dp))
                    Text("940", color = Color.White, fontSize = 10.sp)
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(24.dp))
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 24.dp, end = 60.dp)
                ) {
                    Text(text = "viral_shorts_official • Original audio", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = clip.title, color = Color(0xDDFFFFFF), fontSize = 11.sp, maxLines = 1)
                }
            }
        }

        PlatformOverlay.YOUTUBE_SHORTS -> {
            Box(modifier = modifier) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 10.dp, bottom = 65.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(Icons.Default.ThumbUp, contentDescription = "Like", tint = Color.White, modifier = Modifier.size(26.dp))
                    Text("310K", color = Color.White, fontSize = 10.sp)
                    Icon(Icons.Default.ChatBubble, contentDescription = "Comment", tint = Color.White, modifier = Modifier.size(24.dp))
                    Text("4.2K", color = Color.White, fontSize = 10.sp)
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(24.dp))
                    Text("Share", color = Color.White, fontSize = 10.sp)
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 24.dp, end = 60.dp)
                ) {
                    Text(text = clip.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(text = "ViralShorts AI • Subscribe", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
