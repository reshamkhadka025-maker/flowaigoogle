package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AspectCropMode
import com.example.model.CaptionStylePreset
import com.example.model.Language
import com.example.model.MusicTrack
import com.example.model.PlatformOverlay
import com.example.model.ViralClip
import com.example.model.VoiceCloneProfile
import com.example.model.VoicePersona
import com.example.ui.components.CaptionStylePresetSelector
import com.example.ui.components.CopyrightSafetyCard
import com.example.ui.components.PlatformOverlaySelector
import com.example.ui.components.VerticalVideoPlayer
import com.example.ui.components.ViralityScoreBadge
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ViralFlame
import com.example.ui.theme.ViralGold

enum class EditorTab(val title: String) {
    CAPTIONS("Captions & Style"),
    FRAMING("9:16 Framing"),
    DUBBING("Dub & Lip-Sync"),
    HOOKS_SEO("Hooks & Hashtags"),
    COPYRIGHT("Copyright Guard")
}

@Composable
fun ClipEditorScreen(
    clip: ViralClip,
    voiceProfiles: List<VoiceCloneProfile>,
    onBack: () -> Unit,
    onSaveClip: (ViralClip) -> Unit,
    onExportClip: (ViralClip) -> Unit,
    onOpenVoiceCloning: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentClip by remember { mutableStateOf(clip) }
    var selectedTab by remember { mutableStateOf(EditorTab.CAPTIONS) }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Toolbar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        onSaveClip(currentClip)
                        onBack()
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .testTag("clip_editor_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentClip.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ViralityScoreBadge(score = currentClip.viralityScore)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${currentClip.durationSec}s • 9:16 Vertical",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Button(
                    onClick = {
                        onSaveClip(currentClip)
                        onExportClip(currentClip)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    modifier = Modifier.testTag("editor_export_btn")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // 9:16 Interactive Video Player Preview
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp),
                contentAlignment = Alignment.Center
            ) {
                VerticalVideoPlayer(
                    clip = currentClip,
                    onClipChange = {
                        currentClip = it
                        onSaveClip(it)
                    },
                    modifier = Modifier
                        .height(340.dp)
                        .width(192.dp)
                )
            }
        }

        // Studio Navigation Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = DarkSurfaceCard,
                contentColor = NeonCyan,
                edgePadding = 8.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                        color = NeonPink
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, Color(0xFF2E3B52), RoundedCornerShape(14.dp))
            ) {
                EditorTab.values().forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = {
                            Text(
                                text = tab.title,
                                fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp,
                                color = if (selectedTab == tab) Color.White else TextSecondary
                            )
                        }
                    )
                }
            }
        }

        // Active Tab Content
        item {
            when (selectedTab) {
                EditorTab.CAPTIONS -> {
                    CaptionsTabContent(
                        clip = currentClip,
                        onUpdateClip = {
                            currentClip = it
                            onSaveClip(it)
                        }
                    )
                }

                EditorTab.FRAMING -> {
                    FramingTabContent(
                        clip = currentClip,
                        onUpdateClip = {
                            currentClip = it
                            onSaveClip(it)
                        }
                    )
                }

                EditorTab.DUBBING -> {
                    DubbingTabContent(
                        clip = currentClip,
                        voiceProfiles = voiceProfiles,
                        onUpdateClip = {
                            currentClip = it
                            onSaveClip(it)
                        },
                        onOpenVoiceCloning = onOpenVoiceCloning
                    )
                }

                EditorTab.HOOKS_SEO -> {
                    HooksSeoTabContent(
                        clip = currentClip,
                        onUpdateClip = {
                            currentClip = it
                            onSaveClip(it)
                        }
                    )
                }

                EditorTab.COPYRIGHT -> {
                    CopyrightTabContent(clip = currentClip)
                }
            }
        }
    }
}

@Composable
private fun CaptionsTabContent(
    clip: ViralClip,
    onUpdateClip: (ViralClip) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E3B52))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Kinetic Subtitles Preset",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            CaptionStylePresetSelector(
                selectedPreset = clip.captionStyle,
                onSelectPreset = {
                    onUpdateClip(clip.copy(captionStyle = it))
                }
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Platform Safe-Zone overlay selector
            Text(
                text = "Platform Safe-Zone Overlay",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Check whether TikTok or Reels buttons block your captions",
                color = TextSecondary,
                fontSize = 11.sp
            )

            PlatformOverlaySelector(
                selected = clip.platformOverlay,
                onSelect = {
                    onUpdateClip(clip.copy(platformOverlay = it))
                }
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Hook headline editor
            Text(
                text = "Floating Hook Headline",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = clip.hookHeadline,
                onValueChange = {
                    onUpdateClip(clip.copy(hookHeadline = it))
                },
                placeholder = { Text("E.g. WAIT TILL THE END 😱") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonViolet,
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hook_headline_input")
            )
        }
    }
}

@Composable
private fun FramingTabContent(
    clip: ViralClip,
    onUpdateClip: (ViralClip) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E3B52))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Smart 9:16 Aspect Framing",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Converts 16:9 widescreen long-form footage into optimal vertical video for mobile screens.",
                color = TextSecondary,
                fontSize = 11.sp
            )

            AspectCropMode.values().forEach { mode ->
                val isSelected = clip.cropMode == mode
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onUpdateClip(clip.copy(cropMode = mode)) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) NeonViolet.copy(alpha = 0.2f) else DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) NeonViolet else Color(0xFF334155)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NeonViolet else DarkSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Crop,
                                contentDescription = null,
                                tint = if (isSelected) Color.White else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mode.label,
                                color = if (isSelected) Color.White else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = mode.iconDescription,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = "Active", tint = NeonCyan)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DubbingTabContent(
    clip: ViralClip,
    voiceProfiles: List<VoiceCloneProfile>,
    onUpdateClip: (ViralClip) -> Unit,
    onOpenVoiceCloning: () -> Unit
) {
    var showLanguageDropdown by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E3B52))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Target Language Dropdown
            Text(
                text = "Multilingual Video Translation & Dubbing",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            Box {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showLanguageDropdown = true }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(clip.dubbingLanguage.flagEmoji, fontSize = 22.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = clip.dubbingLanguage.name,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = clip.dubbingLanguage.nativeName,
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Text("Change ▼", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                DropdownMenu(
                    expanded = showLanguageDropdown,
                    onDismissRequest = { showLanguageDropdown = false },
                    modifier = Modifier.background(DarkSurfaceCard)
                ) {
                    Language.SUPPORTED_LANGUAGES.forEach { lang ->
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(lang.flagEmoji, fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text("${lang.name} (${lang.nativeName})", color = TextPrimary)
                                }
                            },
                            onClick = {
                                onUpdateClip(clip.copy(dubbingLanguage = lang))
                                showLanguageDropdown = false
                            }
                        )
                    }
                }
            }

            // AI Lip-Sync Switch
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Sync, contentDescription = null, tint = NeonPink, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Automatic AI Lip-Sync", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text(
                            text = "Synthesizes realistic mouth movements to match translated words",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = clip.lipSyncEnabled,
                        onCheckedChange = {
                            onUpdateClip(clip.copy(lipSyncEnabled = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NeonPink
                        ),
                        modifier = Modifier.testTag("lip_sync_switch")
                    )
                }
            }

            // AI Voice Persona Selection
            Text(
                text = "Voice Synthesis & AI Voice Changing",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            VoicePersona.DEFAULT_VOICES.forEach { voice ->
                val isSelected = clip.voicePersona.id == voice.id
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onUpdateClip(clip.copy(voicePersona = voice)) },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) NeonViolet.copy(alpha = 0.2f) else DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) NeonViolet else Color(0xFF334155)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = if (isSelected) NeonCyan else TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(voice.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(voice.style, color = TextSecondary, fontSize = 10.sp)
                        }
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = "Active", tint = NeonCyan, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // Cloned Voice Profile button
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenVoiceCloning() },
                shape = RoundedCornerShape(10.dp),
                color = DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonViolet)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎙️", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Use My Cloned Voice", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Trained on your verified vocal profile", color = NeonCyan, fontSize = 10.sp)
                        }
                    }
                    Text("Configure →", color = NeonPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Audio Ducking Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Background Music Ducking", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${clip.musicVolumePercent}% volume under speech", color = NeonCyan, fontSize = 11.sp)
                }
                Slider(
                    value = clip.musicVolumePercent.toFloat(),
                    onValueChange = {
                        onUpdateClip(clip.copy(musicVolumePercent = it.toInt()))
                    },
                    valueRange = 5f..60f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan
                    )
                )
            }
        }
    }
}

@Composable
private fun HooksSeoTabContent(
    clip: ViralClip,
    onUpdateClip: (ViralClip) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E3B52))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "AI Viral Hooks & Headlines",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            val suggestedHooks = listOf(
                "STOP DOING THIS IN 2025! 🛑",
                "WAIT TILL THE END 😱",
                "The 1 Brutal Truth About Success 💡",
                "Why 99% Of People Fail At This 📉"
            )

            suggestedHooks.forEach { hook ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onUpdateClip(clip.copy(hookHeadline = hook)) },
                    shape = RoundedCornerShape(8.dp),
                    color = if (clip.hookHeadline == hook) NeonViolet.copy(alpha = 0.25f) else DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (clip.hookHeadline == hook) NeonViolet else Color(0xFF334155)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(hook, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        if (clip.hookHeadline == hook) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Hashtags with 1-click copy
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Viral Platform Hashtags",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = {
                        val tags = clip.hashtags.joinToString(" ")
                        clipboardManager.setText(AnnotatedString(tags))
                        Toast.makeText(context, "Hashtags copied to clipboard!", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy all hashtags", tint = NeonCyan, modifier = Modifier.size(18.dp))
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(clip.hashtags) { tag ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = tag,
                            color = NeonPink,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // SEO Description
            Text(
                text = "Optimized Video Description",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = clip.seoDescription,
                onValueChange = {
                    onUpdateClip(clip.copy(seoDescription = it))
                },
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonViolet,
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun CopyrightTabContent(clip: ViralClip) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        CopyrightSafetyCard(audit = clip.copyrightAudit)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E3B52))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Monetization & Fair Use Compliance",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("YouTube ContentID Safe (Audio Fingerprint clear)", color = TextPrimary, fontSize = 12.sp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TikTok Commercial Music Library License included", color = TextPrimary, fontSize = 12.sp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Instagram Reels Audio Rights Verified", color = TextPrimary, fontSize = 12.sp)
                }
            }
        }
    }
}
