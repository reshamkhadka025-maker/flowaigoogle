package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AspectCropMode
import com.example.model.CaptionStylePreset
import com.example.model.CopyrightAudit
import com.example.model.Language
import com.example.model.PlatformOverlay
import com.example.model.SafetyLevel
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.ViralFlame
import com.example.ui.theme.ViralGold

@Composable
fun ViralityScoreBadge(
    score: Int,
    modifier: Modifier = Modifier
) {
    val (gradientColors, iconTint) = when {
        score >= 95 -> listOf(Color(0xFFFF2A2A), Color(0xFFFF7A00)) to Color.White
        score >= 90 -> listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)) to Color.White
        else -> listOf(Color(0xFF06B6D4), Color(0xFF3B82F6)) to Color.White
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.horizontalGradient(gradientColors))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (score >= 95) Icons.Default.LocalFireDepartment else Icons.Default.Bolt,
                contentDescription = "Virality Indicator",
                tint = iconTint,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = "$score% VIRAL",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun CopyrightSafetyCard(
    audit: CopyrightAudit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E3B52))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0x2210B981)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Copyright Safety",
                    tint = EmeraldGreen,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Copyright & Monetization Guard",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0x3310B981)
                    ) {
                        Text(
                            text = "${audit.scorePercent}% SAFE",
                            color = EmeraldGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = audit.description,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
fun PlatformOverlaySelector(
    selected: PlatformOverlay,
    onSelect: (PlatformOverlay) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        PlatformOverlay.values().forEach { overlay ->
            val isSelected = overlay == selected
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelect(overlay) },
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) NeonViolet.copy(alpha = 0.25f) else DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) NeonViolet else Color(0xFF2E3B52)
                )
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = when (overlay) {
                            PlatformOverlay.NONE -> "Clean"
                            PlatformOverlay.TIKTOK -> "TikTok"
                            PlatformOverlay.REELS -> "Reels"
                            PlatformOverlay.YOUTUBE_SHORTS -> "Shorts"
                        },
                        color = if (isSelected) Color.White else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun CaptionStylePresetSelector(
    selectedPreset: CaptionStylePreset,
    onSelectPreset: (CaptionStylePreset) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        CaptionStylePreset.ALL_PRESETS.forEach { preset ->
            val isSelected = preset.id == selectedPreset.id
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelectPreset(preset) },
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) NeonPink.copy(alpha = 0.2f) else DarkSurfaceCard,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) NeonPink else Color(0xFF2E3B52)
                )
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Preview sample text
                    Text(
                        text = "VIRAL",
                        color = preset.highlightColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = preset.name.split(" ").first(),
                        color = if (isSelected) TextPrimary else TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
