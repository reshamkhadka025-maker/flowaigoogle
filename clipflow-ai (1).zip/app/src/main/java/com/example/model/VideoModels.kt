package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CaptionHormoziGreen
import com.example.ui.theme.CaptionHormoziRed
import com.example.ui.theme.CaptionHormoziYellow
import com.example.ui.theme.CaptionNeonPink
import com.example.ui.theme.NeonCyan

enum class AspectCropMode(val label: String, val iconDescription: String) {
    AUTO_SPEAKER_TRACK("AI Auto Face-Track", "Centers and smoothly follows the active speaker"),
    CENTER_9_16("Center 9:16 Crop", "Crops the central 9:16 vertical viewport"),
    DUAL_SPLIT("Podcast Dual Split", "Shows speaker on top half and reaction on bottom half"),
    BLURRED_CANVAS("9:16 Blur Background", "Presents full 16:9 frame with blurred ambient backdrop")
}

enum class PlatformOverlay(val displayName: String, val icon: String) {
    NONE("Clean", "No Overlay"),
    TIKTOK("TikTok UI", "Right icons + bottom sound caption mask"),
    REELS("Instagram Reels", "Right heart/comment + bottom meta mask"),
    YOUTUBE_SHORTS("YouTube Shorts", "Right engagement stack + bottom title")
}

data class CaptionWord(
    val word: String,
    val startMs: Long,
    val endMs: Long,
    val isEmphasized: Boolean = false,
    val emoji: String? = null
)

enum class CaptionAnimationStyle {
    BOUNCE_ZOOM,
    KARAOKE_SWEEP,
    PUNCHY_POP,
    MINIMAL_FADE
}

data class CaptionStylePreset(
    val id: String,
    val name: String,
    val textColor: Color,
    val highlightColor: Color,
    val hasBackgroundBox: Boolean = false,
    val boxColor: Color = Color.Transparent,
    val isAllCaps: Boolean = true,
    val animation: CaptionAnimationStyle = CaptionAnimationStyle.BOUNCE_ZOOM
) {
    companion object {
        val HORMOZI = CaptionStylePreset(
            id = "hormozi",
            name = "Hormozi Punchy",
            textColor = Color.White,
            highlightColor = CaptionHormoziYellow,
            hasBackgroundBox = false,
            isAllCaps = true,
            animation = CaptionAnimationStyle.PUNCHY_POP
        )
        val MR_BEAST = CaptionStylePreset(
            id = "mrbeast",
            name = "MrBeast Bold",
            textColor = Color.White,
            highlightColor = CaptionHormoziGreen,
            hasBackgroundBox = true,
            boxColor = Color(0xCC000000),
            isAllCaps = true,
            animation = CaptionAnimationStyle.BOUNCE_ZOOM
        )
        val CYBER_NEON = CaptionStylePreset(
            id = "cyber_neon",
            name = "Cyber Glow",
            textColor = NeonCyan,
            highlightColor = CaptionNeonPink,
            hasBackgroundBox = false,
            isAllCaps = true,
            animation = CaptionAnimationStyle.KARAOKE_SWEEP
        )
        val MINIMALIST = CaptionStylePreset(
            id = "minimal",
            name = "Minimal Clean",
            textColor = Color.White,
            highlightColor = Color(0xFFFBBF24),
            hasBackgroundBox = false,
            isAllCaps = false,
            animation = CaptionAnimationStyle.MINIMAL_FADE
        )

        val ALL_PRESETS = listOf(HORMOZI, MR_BEAST, CYBER_NEON, MINIMALIST)
    }
}

data class Language(
    val code: String,
    val name: String,
    val nativeName: String,
    val flagEmoji: String
) {
    companion object {
        val ORIGINAL = Language("orig", "Original Audio", "Native", "🎙️")
        val SPANISH = Language("es", "Spanish", "Español", "🇪🇸")
        val HINDI = Language("hi", "Hindi", "हिन्दी", "🇮🇳")
        val JAPANESE = Language("ja", "Japanese", "日本語", "🇯🇵")
        val FRENCH = Language("fr", "French", "Français", "🇫🇷")
        val GERMAN = Language("de", "German", "Deutsch", "🇩🇪")
        val PORTUGUESE = Language("pt", "Portuguese", "Português", "🇧🇷")
        val ARABIC = Language("ar", "Arabic", "العربية", "🇸🇦")
        val CHINESE = Language("zh", "Chinese", "中文", "🇨🇳")
        val KOREAN = Language("ko", "Korean", "한국어", "🇰🇷")
        val ITALIAN = Language("it", "Italian", "Italiano", "🇮🇹")

        val SUPPORTED_LANGUAGES = listOf(
            ORIGINAL, SPANISH, HINDI, JAPANESE, FRENCH, GERMAN, PORTUGUESE, ARABIC, CHINESE, KOREAN, ITALIAN
        )
    }
}

data class VoicePersona(
    val id: String,
    val name: String,
    val style: String,
    val gender: String,
    val isCloned: Boolean = false,
    val pitchMultiplier: Float = 1.0f,
    val speedMultiplier: Float = 1.0f
) {
    companion object {
        val ORIGINAL = VoicePersona("orig", "Original Voice", "Speaker's real voice timbre", "Natural")
        val STUDIO_PRO = VoicePersona("studio_pro", "Studio Narrator", "Authoritative, crisp documentary", "Male", pitchMultiplier = 0.95f)
        val HYPE_HOST = VoicePersona("hype_host", "Hype Creator", "Fast, high-energy gaming podcast", "Neutral", speedMultiplier = 1.08f)
        val CALM_DEEP = VoicePersona("calm_deep", "Deep Storyteller", "Warm, soothing ASMR baritone", "Male", pitchMultiplier = 0.88f)
        val VIBRANT_FEMALE = VoicePersona("vibrant_f", "Nova Dynamic", "Friendly, persuasive tech explainer", "Female", pitchMultiplier = 1.05f)

        val DEFAULT_VOICES = listOf(ORIGINAL, STUDIO_PRO, HYPE_HOST, CALM_DEEP, vibrantVoice())

        private fun vibrantVoice() = VIBRANT_FEMALE
    }
}

data class VoiceCloneProfile(
    val id: String,
    val speakerName: String,
    val consentStatement: String,
    val consentTimestamp: Long,
    val sampleDurationSec: Int,
    val similarityConfidence: Int = 98,
    val status: String = "Ready to Dub",
    val isVerified: Boolean = true
)

data class MusicTrack(
    val id: String,
    val title: String,
    val mood: String,
    val bpm: Int,
    val durationSec: Int,
    val licenseNotice: String = "100% Royalty Free & Monetization Safe"
) {
    companion object {
        val TRACK_LOFI = MusicTrack("m1", "Midnight Focus Beat", "Lo-Fi / Chill", 85, 120)
        val TRACK_HYPE = MusicTrack("m2", "Viral Drift Phonk", "Energetic / High Tempo", 135, 90)
        val TRACK_CINEMATIC = MusicTrack("m3", "Inception Pulse", "Dramatic / Suspense", 110, 150)
        val TRACK_TECH = MusicTrack("m4", "Silicon Valley Drive", "Upbeat / Tech Pop", 120, 110)

        val ALL_TRACKS = listOf(TRACK_LOFI, TRACK_HYPE, TRACK_CINEMATIC, TRACK_TECH)
    }
}

enum class SafetyLevel {
    SAFE_TO_MONETIZE,
    FAIR_USE_VERIFIED,
    REVIEW_RECOMMENDED
}

data class CopyrightAudit(
    val safetyLevel: SafetyLevel,
    val scorePercent: Int,
    val description: String,
    val audioFingerprint: String,
    val canMonetize: Boolean = true
)

data class ViralClip(
    val id: String,
    val projectId: String,
    val title: String,
    val hookHeadline: String,
    val startSec: Int,
    val endSec: Int,
    val viralityScore: Int, // 0-100
    val hookStrengthScore: Int,
    val emotionalSpikeType: String,
    val viralReason: String,
    val transcript: List<CaptionWord>,
    val captionStyle: CaptionStylePreset = CaptionStylePreset.HORMOZI,
    val cropMode: AspectCropMode = AspectCropMode.AUTO_SPEAKER_TRACK,
    val platformOverlay: PlatformOverlay = PlatformOverlay.TIKTOK,
    val dubbingLanguage: Language = Language.ORIGINAL,
    val voicePersona: VoicePersona = VoicePersona.ORIGINAL,
    val lipSyncEnabled: Boolean = true,
    val backgroundMusic: MusicTrack? = MusicTrack.TRACK_LOFI,
    val musicVolumePercent: Int = 25,
    val hashtags: List<String> = listOf("#viral", "#shorts", "#trending", "#mindset"),
    val seoDescription: String = "Watch till the end to unlock the game changer! 🚀",
    val copyrightAudit: CopyrightAudit = CopyrightAudit(
        SafetyLevel.SAFE_TO_MONETIZE,
        99,
        "No audio copyright match found. Safe for commercial monetization on YouTube, TikTok & Reels.",
        "Clear of ContentID & RightsManager"
    ),
    val isExported: Boolean = false
) {
    val durationSec: Int get() = (endSec - startSec).coerceAtLeast(1)
}

data class LongVideoProject(
    val id: String,
    val title: String,
    val sourceUrl: String?,
    val sourceFileName: String?,
    val originalDurationSec: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val thumbnailGradient: List<Color>,
    val clips: List<ViralClip> = emptyList()
)
