package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.VideoRepository
import com.example.model.Language
import com.example.model.LongVideoProject
import com.example.model.ViralClip
import com.example.model.VoiceCloneProfile
import com.example.ui.screens.ClipEditorScreen
import com.example.ui.screens.ClipsOverviewScreen
import com.example.ui.screens.ExportShareScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProcessingScreen
import com.example.ui.screens.VoiceCloningScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class Screen {
    data object Home : Screen()
    data class Processing(val projectTitle: String) : Screen()
    data class ClipsOverview(val projectId: String) : Screen()
    data class ClipEditor(val clipId: String) : Screen()
    data object VoiceCloning : Screen()
    data class ExportShare(val clipId: String) : Screen()
}

class MainViewModel(
    private val repository: VideoRepository = VideoRepository()
) : ViewModel() {

    val projects: StateFlow<List<LongVideoProject>> = repository.projects
    val voiceProfiles: StateFlow<List<VoiceCloneProfile>> = repository.voiceProfiles

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val navStack = mutableListOf<Screen>(Screen.Home)

    var pipelineProgress by mutableStateOf(0)
        private set
    var pipelineStatus by mutableStateOf("Initializing AI pipeline...")
        private set

    fun navigateTo(screen: Screen) {
        navStack.add(screen)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (navStack.size > 1) {
            navStack.removeAt(navStack.size - 1)
            _currentScreen.value = navStack.last()
            return true
        }
        return false
    }

    fun startProcessingVideo(
        title: String,
        url: String?,
        fileName: String?,
        targetLang: Language,
        onFinished: (String) -> Unit
    ) {
        navigateTo(Screen.Processing(title))
        viewModelScopeLaunch {
            repository.processVideo(title, url, fileName, targetLang).collect { (prog, status) ->
                pipelineProgress = prog
                pipelineStatus = status
                if (prog >= 100) {
                    val latestProject = repository.projects.value.firstOrNull()
                    if (latestProject != null) {
                        navStack.remove(Screen.Processing(title))
                        navigateTo(Screen.ClipsOverview(latestProject.id))
                        onFinished(latestProject.id)
                    }
                }
            }
        }
    }

    fun getProject(id: String): LongVideoProject? = repository.getProject(id)

    fun getClip(clipId: String): ViralClip? = repository.getClip(clipId)

    fun updateClip(clip: ViralClip) {
        repository.updateClip(clip)
    }

    fun addVoiceProfile(profile: VoiceCloneProfile) {
        repository.addVoiceProfile(profile)
    }

    private var coroutineScope: kotlinx.coroutines.CoroutineScope? = null
    fun attachScope(scope: kotlinx.coroutines.CoroutineScope) {
        coroutineScope = scope
    }

    private fun viewModelScopeLaunch(block: suspend () -> Unit) {
        coroutineScope?.launch { block() }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(viewModel: MainViewModel = viewModel()) {
    val coroutineScope = rememberCoroutineScope()
    viewModel.attachScope(coroutineScope)

    val currentScreen by viewModel.currentScreen.collectAsState()
    val projects by viewModel.projects.collectAsState()
    val voiceProfiles by viewModel.voiceProfiles.collectAsState()

    // Handle system back navigation
    BackHandler(enabled = currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    val showBottomNav = currentScreen is Screen.Home || currentScreen is Screen.VoiceCloning

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = DarkBackground,
        bottomBar = {
            if (showBottomNav) {
                NavigationBar(
                    containerColor = DarkSurface,
                    contentColor = TextPrimary,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("main_bottom_nav")
                ) {
                    NavigationBarItem(
                        selected = currentScreen is Screen.Home,
                        onClick = { viewModel.navigateTo(Screen.Home) },
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Repurpose") },
                        label = { Text("Repurpose", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NeonViolet,
                            selectedTextColor = NeonViolet,
                            indicatorColor = NeonViolet.copy(alpha = 0.2f),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    NavigationBarItem(
                        selected = false,
                        onClick = {
                            val firstProject = projects.firstOrNull()
                            if (firstProject != null) {
                                viewModel.navigateTo(Screen.ClipsOverview(firstProject.id))
                            }
                        },
                        icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "Clips") },
                        label = { Text("Clips Studio", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_clips")
                    )

                    NavigationBarItem(
                        selected = currentScreen is Screen.VoiceCloning,
                        onClick = { viewModel.navigateTo(Screen.VoiceCloning) },
                        icon = { Icon(Icons.Default.Mic, contentDescription = "Voice Clone") },
                        label = { Text("Voice Clone", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NeonPink,
                            selectedTextColor = NeonPink,
                            indicatorColor = NeonPink.copy(alpha = 0.2f),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_voice")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                is Screen.Home -> {
                    HomeScreen(
                        projects = projects,
                        onStartProcessing = { title, url, fileName, targetLang ->
                            viewModel.startProcessingVideo(title, url, fileName, targetLang) {}
                        },
                        onSelectProject = { project ->
                            viewModel.navigateTo(Screen.ClipsOverview(project.id))
                        },
                        onOpenVoiceCloning = {
                            viewModel.navigateTo(Screen.VoiceCloning)
                        }
                    )
                }

                is Screen.Processing -> {
                    ProcessingScreen(
                        progressPercent = viewModel.pipelineProgress,
                        statusText = viewModel.pipelineStatus
                    )
                }

                is Screen.ClipsOverview -> {
                    val project = viewModel.getProject(screen.projectId)
                    if (project != null) {
                        ClipsOverviewScreen(
                            project = project,
                            onBack = { viewModel.navigateBack() },
                            onSelectClip = { clip ->
                                viewModel.navigateTo(Screen.ClipEditor(clip.id))
                            },
                            onExportClip = { clip ->
                                viewModel.navigateTo(Screen.ExportShare(clip.id))
                            },
                            onBatchExport = {
                                val firstClip = project.clips.firstOrNull()
                                if (firstClip != null) {
                                    viewModel.navigateTo(Screen.ExportShare(firstClip.id))
                                }
                            }
                        )
                    } else {
                        viewModel.navigateBack()
                    }
                }

                is Screen.ClipEditor -> {
                    val clip = viewModel.getClip(screen.clipId)
                    if (clip != null) {
                        ClipEditorScreen(
                            clip = clip,
                            voiceProfiles = voiceProfiles,
                            onBack = { viewModel.navigateBack() },
                            onSaveClip = { updatedClip ->
                                viewModel.updateClip(updatedClip)
                            },
                            onExportClip = { clipToExport ->
                                viewModel.navigateTo(Screen.ExportShare(clipToExport.id))
                            },
                            onOpenVoiceCloning = {
                                viewModel.navigateTo(Screen.VoiceCloning)
                            }
                        )
                    } else {
                        viewModel.navigateBack()
                    }
                }

                is Screen.VoiceCloning -> {
                    VoiceCloningScreen(
                        profiles = voiceProfiles,
                        onBack = { viewModel.navigateBack() },
                        onProfileCreated = { newProfile ->
                            viewModel.addVoiceProfile(newProfile)
                        }
                    )
                }

                is Screen.ExportShare -> {
                    val clip = viewModel.getClip(screen.clipId)
                    if (clip != null) {
                        ExportShareScreen(
                            clip = clip,
                            onBack = { viewModel.navigateBack() },
                            onFinishExport = {
                                viewModel.navigateTo(Screen.Home)
                            }
                        )
                    } else {
                        viewModel.navigateBack()
                    }
                }
            }
        }
    }
}
